The allotments pattern is based on allotments.svg

However, since SVG patterns is not properly handled by Mapnik at this time, the SVG file was converted to a PNG file with alpha channel, allotments.png
