These scripts are necessary and useful solely during making changes to the map style.

There are unnecessary for map rendering.